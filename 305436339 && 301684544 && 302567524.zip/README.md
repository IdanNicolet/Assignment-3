# Assignment-3
Therer are four main Folders in GIT for this assigmnet:
  1. Server-side: contains all the php files uploaded to our server).
  2. MatchRace-master: contains the Android Studio source files.
  3. Race Mannager Application: contains the mannager application for creating the KML files.
  4. Documentation: contains our report for the assignment.
  5. Ex3_extras: contains the instructions and all other files that was given to us.
